package com.atguigu.filter;

import com.atguigu.utils.JdbcUtils;

import javax.servlet.*;
import java.io.IOException;
import java.rmi.RemoteException;

public class TransactionFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    /**
     * 通过filter和try-catch事务管理的结合，完美的做到AOP编程，太妙了
     * @param servletRequest
     * @param servletResponse
     * @param filterChain
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        try {
            filterChain.doFilter(servletRequest, servletResponse);
            JdbcUtils.commitAndClose(); //  提交事物
        } catch (Exception e) {
            JdbcUtils.roolbackAndClose();   //  回滚事务
            e.printStackTrace();
            throw new RuntimeException(e);  //把异常抛给服务器
        }
    }

    @Override
    public void destroy() {

    }
}
