package com.atguigu.web;

import com.atguigu.pojo.User;
import com.atguigu.service.UserService;
import com.atguigu.service.impl.UserServiceImpl;
import com.atguigu.utils.WebUtils;
import com.google.gson.Gson;
import jdk.nashorn.internal.parser.TokenType;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import static com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY;

public class UserServlet extends BaseServlet {

    private UserService userService = new UserServiceImpl();

    /**
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void ajaxExistUsername(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //  获取参数
        String username = req.getParameter("username");
        //  调用service
        boolean isExist = userService.existUsername(username);
        //  把结果封装成为map对象
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("isExist", isExist);
        Gson gson = new Gson();
        String json = gson.toJson(resultMap);
        resp.getWriter().write(json);
    }

    /**
     * 注销
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void logout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //  1、销毁session中的数据
        req.getSession().invalidate();
        //  2、重定向到首页（或者登录页面）
        resp.sendRedirect(req.getContextPath());
        System.out.println("ok");
    }

    /**
     * 处理登录的功能
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //  获取请求参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        //  调用service处理业务
        User loginUser = userService.login(new User(null, username, password, null));

        //  如果loginUser是空，就是登陆失败
        if (loginUser == null) {
            //  登录失败，跳回登录页面
            req.setAttribute("msg", "用户名或密码错误！登录失败！");
            //  把错误信息和回显的表单信息保存到request域中
            req.setAttribute("username", username);
            //  跳转回去
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req, resp);

        } else {
            //  登录成功，保存用户登录之后的信息到session域中
            req.getSession().setAttribute("user", loginUser);
            req.getRequestDispatcher("/pages/user/login_success.jsp").forward(req, resp);
        }
    }

    /**
     * 处理注册的功能
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void regist(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //  获取谷歌验证码，并删除原来的验证码
        String token = (String) req.getSession().getAttribute(KAPTCHA_SESSION_KEY);
        req.getSession().removeAttribute(KAPTCHA_SESSION_KEY);


        //  获取请求参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String email = req.getParameter("email");
        String code = req.getParameter("code");

        //  使用自己写的工具类来代替进行复用
        User user = WebUtils.copyParamToBean(req.getParameterMap(), new User());

        //  验证码，先写死
        if (token != null && token.equalsIgnoreCase(code)) {
            //  检查用户名
            if (userService.existUsername(username)) {
                //  不可用
                req.setAttribute("msg", "用户名" + username + "已经存在！");
                req.setAttribute("username", username);
                req.setAttribute("email", email);

                req.getRequestDispatcher("/pages/user/regist.jsp").forward(req, resp);
            } else {
                //  可用，保存
                userService.registUser(new User(null, username, password, email));

                //  注册成功跳转
                req.getRequestDispatcher("/pages/user/regist_success.jsp").forward(req, resp);
            }

        } else {
            //  把回显信息保存到request域中
            req.setAttribute("msg", "验证码错误！");
            req.setAttribute("username", username);
            req.setAttribute("email", email);

            req.getRequestDispatcher("/pages/user/regist.jsp").forward(req, resp);
        }
    }
}
