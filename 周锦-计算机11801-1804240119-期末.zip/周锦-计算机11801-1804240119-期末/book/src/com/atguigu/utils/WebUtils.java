package com.atguigu.utils;

import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

public class WebUtils {

    /**
     * 自动读取request获取的参数并写入bean类中
     * @param map
     * @param bean
     */
    public static<T> T copyParamToBean(Map map, T bean){
        try {
            //System.out.println("注入之前" + bean);
            /**
             * 自动把所有请求的参数注入到对象中
             * 从而代替上面的很多行
             */
            BeanUtils.populate(bean, map);
            //System.out.println("注入之后" + bean);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bean;
    }

    /**
     * 将字符串转化成int类型的数据
     * @param strInt
     * @param defaultValue
     * @return
     */
    public static int parseInt(String strInt, int defaultValue){
        try {
            return Integer.parseInt(strInt);
        } catch (Exception e){
            //e.printStackTrace();
        }
        return defaultValue;
    }
}
